declare module 'react-native-dotenv' {
  export const REACT_APP_BASE_API_URL: string;
  export const REACT_APP_ONESIGNAL_APP_ID: string;
}
