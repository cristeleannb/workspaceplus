export type WSDirectReportViewType = 'Weekly' | 'Monthly';

export enum ManageTeamWorkforceTypes {
  WFA = 'WFA',
  WFB = 'WFB',
  WFO = 'WFO',
}
