export enum NotificationCategoryEnum {
  MANAGE_TEAM_SCHEDULE = 0,
  PLAN_SCHEDULE = 1,
  WORKSTATION = 2,
  PARKING = 3,
  CHECK_IN = 4,
}
