export enum AccountRole {
  Employee = 1,
  PeopleManager = 2,
  ExecutiveAssistant = 3,
  ExCom = 4,
  SystemAdministrator = 5,
  CEO = 6,
  SpecialExcom = 7,
}
