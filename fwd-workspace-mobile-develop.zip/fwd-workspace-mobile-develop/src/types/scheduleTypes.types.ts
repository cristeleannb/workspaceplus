export enum ScheduleType {
  WFO = 'WFO',
  WFA = 'WFA',
  WFB = 'WFB',
}
